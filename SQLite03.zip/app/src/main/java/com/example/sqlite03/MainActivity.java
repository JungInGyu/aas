package com.example.sqlite03;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        helper = new DBHelper(this);
        helper.onCreate(helper.getWritableDatabase());
        TextView textView = findViewById(R.id.textView);
        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.deleteData();
            }
        });

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder builder = new StringBuilder();
                Cursor cursor = helper.search();
                while (cursor.moveToNext()) {
                   builder.append(cursor.getString(0)).append(" ")
                           .append(cursor.getString(1)).append(" ")
                           .append(cursor.getString(2)).append("\n");
                }
                cursor.close();
                textView.setText(builder.toString());
            }
        });

        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.insertData1();
            }
        });

    }
}