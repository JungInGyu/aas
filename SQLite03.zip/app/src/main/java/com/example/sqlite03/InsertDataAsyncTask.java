package com.example.sqlite03;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

public class InsertDataAsyncTask extends AsyncTask<String, String, Long> {
    private Context context;
    private TextView textView;
    private String type;
    private MyDBHelper helper;

    public InsertDataAsyncTask(Context context, TextView textView, String type) {
        this.context = context;
        this.textView = textView;
        this.type = type;
        helper = new MyDBHelper(context);
    }

    @Override
    protected Long doInBackground(String... strings) {
        Long time = 0L;
        int count = Integer.parseInt(strings[0]);
        long start = System.nanoTime();
        if (type.equals("normal")) {
            helper.insertNormal(count);
        } else if (type.equals("transaction")) {
            helper.insertTransaction(count);
        } else if (type.equals("fast")) {
            helper.fast(count);
        } else {
            helper.insertFast(count);
        }
        long end = System.nanoTime();
        time = end - start;
        return  time;
    }

    @Override
    protected void onPostExecute(Long aLong) {
        textView.append(String.format("\n %s type : %,d \n", type, aLong));
    }
}
