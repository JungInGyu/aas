package com.example.sqlite03;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private Context context;
    static String DBNAME = "Bread";
    String TBLNMAE = "braed";

    public DBHelper(@Nullable Context context) {
        super(context, DBNAME, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS " + TBLNMAE +
                "(_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, price INTEGER);";
        db.execSQL(sql);
        sql = "CREATE INDEX IF NOT EXISTS TEST ON " + TBLNMAE + "(name);";
        db.execSQL(sql);
        db.beginTransaction();
        try {
            insertData();
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE " + TBLNMAE + ";";
        db.execSQL(sql);
        sql = "DROP INDEX name;";
        db.execSQL(sql);
        onCreate(db);
    }

    public void insertData() {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO " + TBLNMAE + "(name, price) VALUES(?, ?);";
        String[] name = {"붕어빵", "치즈빵", "야채빵"};
        try {
            SQLiteStatement statement = database.compileStatement(sql);
            for (int i = 0; i < name.length; i++) {
                statement.bindString(1, name[i]);
                statement.bindLong(2, 300);
                statement.executeInsert();
            }
            statement.close();
        } catch (Exception e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void deleteData() {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "DELETE FROM " + TBLNMAE + ";";
        database.execSQL(sql);
        database.close();
    }

    public Cursor search() {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "SELECT * FROM " + TBLNMAE + ";";
        Cursor cursor = database.rawQuery(sql, null);
        return cursor;
    }

    public void insertData1() {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT OR REPLACE INTO " + TBLNMAE +
                "(name, price) VALUES(?, ?);";
        String[] name = {"붕어빵1", "치즈빵1", "야채빵1"};
        database.beginTransaction();
        try {
            SQLiteStatement statement = database.compileStatement(sql);
            for (int i = 0; i < name.length; i++) {
                statement.bindString(1, name[i]);
                statement.bindLong(2, 300);
                statement.executeInsert();
            }
            statement.close();
            database.setTransactionSuccessful();
        } catch (Exception e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            database.endTransaction();
        }
    }
}
