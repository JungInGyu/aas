package com.example.sqlite03;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDBHelper extends SQLiteOpenHelper {
    private Context context;
    static String DBNAME = "TRANSACTION";
    String TBLNMAE = "Test";

    public MyDBHelper(@Nullable Context context) {
        super(context, DBNAME, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS " + TBLNMAE +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, description TEXT);";
        db.execSQL(sql);
        sql = "CREATE UNIQUE INDEX location ON "+ TBLNMAE + "(name, description);";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertNormal(int count) {
        SQLiteDatabase database = getWritableDatabase();
        try {
            for (int i = 0; i < count; i++) {
                ContentValues values = new ContentValues();
                values.put("name", "Name #" + (i + 1));
                values.put("description", "Description # " + (i + 1));
                database.insert(TBLNMAE,null, values);
            }
        } catch (Exception e){
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        database.close();
    }

    public void insertTransaction(int count) {
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        try {
            for (int i = 0; i < count; i++) {
                ContentValues values = new ContentValues();
                values.put("name", "Name #" + (i + 1));
                values.put("description", "Description # " + (i + 1));
                database.insert(TBLNMAE,null, values);
            }
            database.setTransactionSuccessful();
        } catch (Exception e){
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            database.endTransaction();
        }
        database.close();
    }

    public void insertFast(int count) {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT OR REPLACE INTO " + TBLNMAE +
                "(name, description) VALUES(?, ?);";
        database.beginTransaction();
        try {
            SQLiteStatement statement = database.compileStatement(sql);
            for (int i = 0; i < count; i++) {
                statement.bindString(1, "Name #" + (i + 1));
                statement.bindString(2, "Description #" + (i + 1));
                statement.executeInsert();
            }
            database.setTransactionSuccessful();
            statement.close();
        } catch (Exception e){
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            database.endTransaction();
        }
        database.close();
    }
    public void fast(int count) {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT OR REPLACE INTO " + TBLNMAE +
                "(name, description) VALUES(?, ?);";

        try {
            SQLiteStatement statement = database.compileStatement(sql);
            for (int i = 0; i < count; i++) {
                statement.bindString(1, "Name #" + (i + 1));
                statement.bindString(2, "Description #" + (i + 1));
                statement.executeInsert();
            }

            statement.close();
        } catch (Exception e){
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        database.close();
    }
}
