package com.example.sqlite03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText editText = findViewById(R.id.editText);
        TextView textView = findViewById(R.id.textView);
        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count = editText.getText().toString();
                if (count.equals("")) {
                    Toast.makeText(MainActivity2.this, "입력하세요", Toast.LENGTH_SHORT).show();
                } else {
                    InsertDataAsyncTask task =
                            new InsertDataAsyncTask(MainActivity2.this, textView, "normal");
                    task.execute(count);
                }
            }
        });

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count = editText.getText().toString();
                if (count.equals("")) {
                    Toast.makeText(MainActivity2.this, "입력하세요", Toast.LENGTH_SHORT).show();
                } else {
                    InsertDataAsyncTask task =
                            new InsertDataAsyncTask(MainActivity2.this, textView, "transaction");
                    task.execute(count);
                }
            }
        });
        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count = editText.getText().toString();
                if (count.equals("")) {
                    Toast.makeText(MainActivity2.this, "입력하세요", Toast.LENGTH_SHORT).show();
                } else {
                    InsertDataAsyncTask task =
                            new InsertDataAsyncTask(MainActivity2.this, textView, "fast");
                    task.execute(count);
                }
            }
        });

        Button button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count = editText.getText().toString();
                if (count.equals("")) {
                    Toast.makeText(MainActivity2.this, "입력하세요", Toast.LENGTH_SHORT).show();
                } else {
                    InsertDataAsyncTask task =
                            new InsertDataAsyncTask(MainActivity2.this, textView, "fastT");
                    task.execute(count);
                }
            }
        });
    }
}